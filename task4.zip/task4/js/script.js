let hambergerIcon=document.getElementById("hambergerIcon");
let mobileLinks=document.getElementById("mobileLinks");
console.log("hello")
hambergerIcon.onclick=function() {
    mobileLinks.classList.toggle("mobile");
    
}
