let menuIconEl = document.getElementById("menuIcon");
let displayMenuEl = document.getElementById("displayMenu");


menuIconEl.onclick=function() {
    displayMenuEl.classList.toggle("menu-items-display");
    
}